package com.example.jsonandasycntask;

public interface OnClick {
    void userClick(UserModel user);
}
